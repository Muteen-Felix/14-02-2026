
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateBirthdayWishes = async () => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Viết một lời chúc mừng sinh nhật cực kỳ ngọt ngào, lãng mạn cho bạn gái tên là 'Em Bé'. Sử dụng tông giọng dễ thương, chân thành. Trả về dưới dạng JSON với cấu trúc: content (đoạn văn chính), wishes (mảng 3 câu chúc ngắn).",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            content: { type: Type.STRING },
            wishes: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["content", "wishes"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      content: "Chúc mừng sinh nhật công chúa của anh! Chúc em luôn xinh đẹp, hạnh phúc và mãi là em bé đáng yêu nhất thế gian.",
      wishes: [
        "Mãi yêu em",
        "Sinh nhật vui vẻ nhé em",
        "Cùng nhau đi hết quãng đường còn lại"
      ]
    };
  }
};
